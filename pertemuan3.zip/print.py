# https://docs.python.org/3/library/functions.html#print
print("test", "angga", "semarang")
# print("test", "angga", "semarang", sep="\n")
print("test", "angga", "semarang", sep="(spasi)", end="(ok)\n")