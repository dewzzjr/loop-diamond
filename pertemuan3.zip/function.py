def tambah(a, b):
    return a + b

hasil = tambah(5, 10)
print(hasil)